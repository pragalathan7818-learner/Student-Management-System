# Student Management System - Deployment & Setup Guide

## Part 1: Running the Django Backend

### Prerequisites
- Python 3.10 or newer
- `pip` package installer
- Virtual environment tool (`venv`)

### 1. Set Up Virtual Environment & Dependencies
```bash
cd backend
python -m venv venv

# On Linux/macOS:
source venv/bin/activate

# On Windows:
venv\Scripts\activate

# Install required Python packages
pip install -r requirements.txt
```

### 2. Apply Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 3. Create Superuser (Optional Admin Panel Access)
```bash
python manage.py createsuperuser
```

### 4. Start the Django Development Server
```bash
python manage.py runserver 8000
```
The Django REST API will be live at `http://127.0.0.1:8000/api/students/`.

---

## Part 2: Deploying the Frontend to Vercel

### 1. Build Verification
Ensure the frontend compiles cleanly:
```bash
npm run build
```

### 2. Configure Environment Variable on Vercel
In the Vercel Project Dashboard:
1. Navigate to **Project Settings** > **Environment Variables**.
2. Add:
   - **Key**: `VITE_API_BASE_URL`
   - **Value**: `https://your-django-backend-domain.com` (e.g., your deployed backend URL on Render, Railway, or Cloud Run).
3. Save and redeploy.

### 3. Deploying via Vercel CLI
```bash
npm install -g vercel
vercel --prod
```

---

## Part 3: CORS Verification
In `backend/student_management/settings.py`, ensure your Vercel frontend URL is whitelisted:
```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "https://your-vercel-app.vercel.app",
]
```
Alternatively, keep `CORS_ALLOW_ALL_ORIGINS = True` during academic lab evaluations for seamless testing.
