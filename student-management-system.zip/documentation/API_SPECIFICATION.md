# Student Management System - REST API Specification

This document details the RESTful API endpoints, request schemas, status codes, and error formats implemented by the Django REST Framework backend.

## Base URL
- Development: `http://localhost:8000/api` or `http://localhost:3000/api`
- Production: `https://<your-backend-domain>/api`

---

## 1. List Students (Search & Filter)
- **Method**: `GET`
- **Path**: `/api/students/`
- **Query Parameters**:
  - `search` *(string, optional)*: Matches student name, email, department, phone, or numeric ID.
  - `department` *(string, optional)*: Exact match filter on department name.
  - `year` *(integer, optional)*: Filter by academic year (1 to 4).
- **Response**: `200 OK`
```json
[
  {
    "id": 101,
    "name": "Aarav Sharma",
    "email": "aarav.sharma@college.edu",
    "department": "Computer Science",
    "year": 3,
    "phone": "+919876543210",
    "created_at": "2026-09-11T12:00:00Z",
    "updated_at": "2026-09-11T12:00:00Z"
  }
]
```

---

## 2. Retrieve Single Student
- **Method**: `GET`
- **Path**: `/api/students/{id}/`
- **Response (Found)**: `200 OK`
```json
{
  "id": 101,
  "name": "Aarav Sharma",
  "email": "aarav.sharma@college.edu",
  "department": "Computer Science",
  "year": 3,
  "phone": "+919876543210",
  "created_at": "2026-09-11T12:00:00Z",
  "updated_at": "2026-09-11T12:00:00Z"
}
```
- **Response (Not Found)**: `404 Not Found`
```json
{
  "detail": "Not found."
}
```

---

## 3. Create Student
- **Method**: `POST`
- **Path**: `/api/students/`
- **Headers**: `Content-Type: application/json`
- **Request Body**:
```json
{
  "name": "Pooja Hegde",
  "email": "pooja.h@college.edu",
  "department": "Information Technology",
  "year": 2,
  "phone": "+919822334455"
}
```
- **Response (Success)**: `201 Created`
- **Response (Validation Error)**: `400 Bad Request`
```json
{
  "email": ["A student with this email address already exists."],
  "year": ["Academic year must be between 1 and 4."]
}
```

---

## 4. Update Student
- **Method**: `PUT`
- **Path**: `/api/students/{id}/`
- **Headers**: `Content-Type: application/json`
- **Request Body**: All fields required.
- **Response**: `200 OK` with updated record or `400 Bad Request`.

---

## 5. Partial Update Student
- **Method**: `PATCH`
- **Path**: `/api/students/{id}/`
- **Headers**: `Content-Type: application/json`
- **Request Body**: Only fields to update (e.g. `{"year": 4}`).
- **Response**: `200 OK` or `400 Bad Request`.

---

## 6. Delete Student
- **Method**: `DELETE`
- **Path**: `/api/students/{id}/`
- **Response (Success)**: `204 No Content`
- **Response (Not Found)**: `404 Not Found`
