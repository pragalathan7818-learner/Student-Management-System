# Student Management System - API Testing Guide

This guide provides ready-to-run `curl` commands for manual and automated verification of all REST endpoints.

---

## 1. Test Health Check
```bash
curl -X GET http://localhost:3000/api/health/
```
**Expected Response**: `200 OK` with status `healthy`.

---

## 2. Test Create Student (POST /api/students/)
```bash
curl -X POST http://localhost:3000/api/students/ \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Kavya Ramesh",
    "email": "kavya.ramesh@college.edu",
    "department": "Computer Science",
    "year": 2,
    "phone": "+919876543299"
  }'
```
**Expected Response**: `201 Created` with generated `id`.

---

## 3. Test Email Uniqueness Validation (Duplicate Email)
```bash
curl -X POST http://localhost:3000/api/students/ \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Another Student",
    "email": "kavya.ramesh@college.edu",
    "department": "Information Technology",
    "year": 1,
    "phone": "+919876543299"
  }'
```
**Expected Response**: `400 Bad Request`
```json
{
  "email": ["student with this email already exists."]
}
```

---

## 4. Test List All Students (GET /api/students/)
```bash
curl -X GET http://localhost:3000/api/students/
```
**Expected Response**: `200 OK` array of all student records.

---

## 5. Test Live Search & Filtering
```bash
# Search by name or email
curl -X GET "http://localhost:3000/api/students/?search=Kavya"

# Filter by Department and Year
curl -X GET "http://localhost:3000/api/students/?department=Computer%20Science&year=2"
```

---

## 6. Test Retrieve Single Record (GET /api/students/{id}/)
```bash
curl -X GET http://localhost:3000/api/students/101/
```
**Expected Response**: `200 OK` single student object.

---

## 7. Test Update Record (PUT /api/students/{id}/)
```bash
curl -X PUT http://localhost:3000/api/students/101/ \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Aarav Sharma",
    "email": "aarav.sharma@college.edu",
    "department": "Computer Science",
    "year": 4,
    "phone": "+919876543210"
  }'
```
**Expected Response**: `200 OK` with updated `year: 4`.

---

## 8. Test Delete Record (DELETE /api/students/{id}/)
```bash
curl -X DELETE http://localhost:3000/api/students/101/
```
**Expected Response**: `204 No Content`.
