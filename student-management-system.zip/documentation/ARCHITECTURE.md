# Student Management System - System Architecture & SOP

## 1. High-Level Architecture

The Student Management System follows a strict, multi-tier decoupled web architecture:

```
+-------------------------------------------------------------+
|                        USER (Browser)                       |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                   REACT FRONTEND (Vite SPA)                 |
|   - Component Hierarchy, Form Validation, UI State         |
|   - Hosted on Vercel                                        |
+-------------------------------------------------------------+
                              |
                              v [HTTP / RESTful JSON]
+-------------------------------------------------------------+
|                    REST API GATEWAY                         |
|   - Endpoint Routing (/api/students/)                       |
|   - CORS Headers Middleware                                 |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|               DJANGO REST FRAMEWORK BACKEND                 |
|   - ViewSets & API Views                                    |
|   - Serializers (Validation & Marshaling)                   |
|   - Business Logic & Error Handling                         |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                        DJANGO ORM                           |
|   - Object Relational Mapping (Student Model)               |
|   - Schema Constraints & Query Optimization                 |
+-------------------------------------------------------------+
                              |
                              v [SQL Queries]
+-------------------------------------------------------------+
|                      RELATIONAL DATABASE                     |
|   - SQLite3 (Development) / PostgreSQL (Production)         |
+-------------------------------------------------------------+
```

---

## 2. Component Architecture

### Frontend Layer (React + Vite)
- **UI Components**:
  - `Header`: System branding, connectivity status, and action controls.
  - `DashboardStats`: Metric cards summarizing student count, departments, and academic year distribution.
  - `SearchBar`: Real-time keyword filter, department selector, and year dropdown.
  - `StudentTable`: Dynamic data table with column sorting, empty state, and action triggers.
  - `StudentModal`: Multi-purpose Add and Edit modal with inline validation feedback.
  - `StudentDetailModal`: Expanded view for individual student record inspection.
  - `DeleteConfirmModal`: Safety dialog preventing accidental deletions.
  - `ToastNotification`: Non-blocking feedback banners for operational results.
- **Service Layer (`src/services/api.ts`)**:
  - Centralized HTTP client consuming `fetch`.
  - Normalizes server error responses from DRF into field-level error mappings.

### Backend Layer (Django REST Framework)
- **`StudentViewSet`**: Inherits from DRF `ModelViewSet` to provide standard REST endpoints.
- **`StudentSerializer`**: Validates incoming JSON attributes against constraints (unique email, phone regex, year range 1-4).
- **`Student` Model**: Maps Python objects to database tables with database-level integrity checks.

---

## 3. End-to-End Data Flow

```mermaid
sequenceDiagram
    autonumber
    actor User as User / Browser
    participant React as React Frontend
    participant API as REST API Router
    participant DRF as Django REST Framework
    participant Serializer as DRF Serializer
    participant ORM as Django ORM
    participant DB as Database (SQLite/Postgres)

    Note over User,DB: Student Creation Flow (POST /api/students/)
    User->>React: Fills form & clicks "Save Student"
    React->>React: Performs client-side validation
    React->>API: POST /api/students/ (JSON payload)
    API->>DRF: Route to StudentViewSet.create()
    DRF->>Serializer: Instantiate StudentSerializer(data=request.data)
    Serializer->>Serializer: Validate required fields, email format, uniqueness
    alt Validation Failed
        Serializer-->>DRF: Raise ValidationError (400)
        DRF-->>React: HTTP 400 Bad Request {email: [...]}
        React-->>User: Display inline red field error
    else Validation Succeeded
        Serializer->>ORM: serializer.save()
        ORM->>DB: INSERT INTO students (...) VALUES (...)
        DB-->>ORM: Acknowledge & return auto ID
        ORM-->>DRF: Student instance
        DRF-->>React: HTTP 201 Created (JSON representation)
        React->>React: Append record to state & show success toast
        React-->>User: Instant table refresh
    end
```

---

## 4. CRUD Request Flow Specifications

| Operation | HTTP Verb | Endpoint | Input Payload | Status Code | Output |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Create** | `POST` | `/api/students/` | `{ name, email, department, year, phone }` | `201 Created` | Created student object with `id` |
| **Read All** | `GET` | `/api/students/` | *Optional query params: `search`, `department`, `year`* | `200 OK` | Array of student objects |
| **Read One** | `GET` | `/api/students/{id}/` | None | `200 OK` / `404 Not Found` | Single student object |
| **Update** | `PUT` | `/api/students/{id}/` | `{ name, email, department, year, phone }` | `200 OK` / `400 Bad Request` | Updated student object |
| **Patch** | `PATCH` | `/api/students/{id}/` | Partial fields (e.g. `{ phone: "+919999999999" }`) | `200 OK` / `400 Bad Request` | Updated student object |
| **Delete** | `DELETE` | `/api/students/{id}/` | None | `204 No Content` / `404 Not Found` | Empty body |
