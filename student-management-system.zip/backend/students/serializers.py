import re
from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    """
    Serializer for the Student model.
    Provides complete validation for CRUD operations.
    """
    class Meta:
        model = Student
        fields = [
            'id',
            'name',
            'email',
            'department',
            'year',
            'phone',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_name(self, value):
        """Validate name is trimmed and has at least 2 characters."""
        trimmed = value.strip()
        if len(trimmed) < 2:
            raise serializers.ValidationError("Student name must be at least 2 characters long.")
        return trimmed

    def validate_email(self, value):
        """Normalize email and verify unique constraint."""
        normalized = value.strip().lower()
        # Check uniqueness during update vs create
        instance = getattr(self, 'instance', None)
        qs = Student.objects.filter(email__iexact=normalized)
        if instance:
            qs = qs.exclude(pk=instance.pk)
        if qs.exists():
            raise serializers.ValidationError("A student with this email address already exists.")
        return normalized

    def validate_year(self, value):
        """Ensure academic year is between 1 and 4 inclusive."""
        if value not in [1, 2, 3, 4]:
            raise serializers.ValidationError("Academic year must be between 1 and 4.")
        return value

    def validate_phone(self, value):
        """Clean phone string and validate numeric pattern."""
        cleaned = re.sub(r'[\s\-]', '', value.strip())
        pattern = r'^\+?[0-9]{10,15}$'
        if not re.match(pattern, cleaned):
            raise serializers.ValidationError(
                "Phone number must contain between 10 and 15 digits, with an optional leading '+'."
            )
        return cleaned
