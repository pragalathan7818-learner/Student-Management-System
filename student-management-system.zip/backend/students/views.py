from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from django.db.models import Q
from django.db import DatabaseError
from .models import Student
from .serializers import StudentSerializer

class StudentViewSet(viewsets.ModelViewSet):
    """
    Complete CRUD ViewSet for Student entity:
    - POST   /api/students/        -> Create (201 Created)
    - GET    /api/students/        -> List / Search / Filter (200 OK)
    - GET    /api/students/{id}/   -> Retrieve (200 OK / 404 Not Found)
    - PUT    /api/students/{id}/   -> Update full record (200 OK / 400 Bad Request)
    - PATCH  /api/students/{id}/   -> Partial update (200 OK / 400 Bad Request)
    - DELETE /api/students/{id}/   -> Remove record (204 No Content / 404 Not Found)
    """
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

    def get_queryset(self):
        """
        Custom query filtering:
        Supports ?search=<term>, ?department=<dept>, ?year=<year>
        """
        queryset = Student.objects.all().order_by('-id')
        search = self.request.query_params.get('search', None)
        department = self.request.query_params.get('department', None)
        year = self.request.query_params.get('year', None)

        if search:
            search = search.strip()
            # Search by name, email, phone, or id (if integer)
            search_filter = (
                Q(name__icontains=search) |
                Q(email__icontains=search) |
                Q(department__icontains=search) |
                Q(phone__icontains=search)
            )
            if search.isdigit():
                search_filter |= Q(id=int(search))
            queryset = queryset.filter(search_filter)

        if department and department.lower() != 'all':
            queryset = queryset.filter(department__iexact=department.strip())

        if year and year.isdigit():
            queryset = queryset.filter(year=int(year))

        return queryset

    def create(self, request, *args, **kwargs):
        """Handle student creation with custom error wrapping."""
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        try:
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        except DatabaseError as e:
            return Response(
                {"detail": f"Database integrity error: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def update(self, request, *args, **kwargs):
        """Handle full update with validation."""
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        try:
            self.perform_update(serializer)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except DatabaseError as e:
            return Response(
                {"detail": f"Database update error: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def destroy(self, request, *args, **kwargs):
        """Handle student deletion."""
        instance = self.get_object()
        try:
            self.perform_destroy(instance)
            return Response(status=status.HTTP_204_NO_CONTENT)
        except DatabaseError as e:
            return Response(
                {"detail": f"Database deletion error: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    @action(detail=False, methods=['post'], url_path='reset')
    def reset_demo(self, request):
        """Utility action to populate default demo students."""
        sample_students = [
            {"name": "Aarav Sharma", "email": "aarav.sharma@college.edu", "department": "Computer Science", "year": 3, "phone": "+919876543210"},
            {"name": "Diya Patel", "email": "diya.patel@college.edu", "department": "Information Technology", "year": 2, "phone": "+919812345678"},
            {"name": "Rohan Iyer", "email": "rohan.iyer@college.edu", "department": "Electronics & Communication", "year": 4, "phone": "+919734567890"},
            {"name": "Sneha Mukherjee", "email": "sneha.m@college.edu", "department": "Mechanical Engineering", "year": 1, "phone": "+919623456781"},
            {"name": "Vikram Malhotra", "email": "vikram.m@college.edu", "department": "Civil Engineering", "year": 3, "phone": "+919534567892"},
        ]
        Student.objects.all().delete()
        for item in sample_students:
            Student.objects.create(**item)
        return Response(
            {"message": "Database successfully reset with sample students.", "count": len(sample_students)},
            status=status.HTTP_200_OK
        )
