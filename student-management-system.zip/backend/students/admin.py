from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'email', 'department', 'year', 'phone', 'created_at')
    list_filter = ('department', 'year')
    search_fields = ('name', 'email', 'phone', 'id')
    ordering = ('-id',)
