from django.db import migrations, models
import django.core.validators

class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Student',
            fields=[
                ('id', models.BigAutoField(primary_key=True, serialize=False)),
                ('name', models.CharField(help_text='Full legal name of the student', max_length=100)),
                ('email', models.EmailField(help_text='Unique institutional or personal email address', max_length=254, unique=True)),
                ('department', models.CharField(help_text='Academic department name (e.g. Computer Science)', max_length=100)),
                ('year', models.PositiveSmallIntegerField(help_text='Current academic year of study (1 to 4)', validators=[django.core.validators.MinValueValidator(1, message='Academic year must be at least 1.'), django.core.validators.MaxValueValidator(4, message='Academic year cannot exceed 4.')])),
                ('phone', models.CharField(help_text='Contact telephone/mobile number', max_length=15, validators=[django.core.validators.RegexValidator(message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.", regex='^\\+?[0-9]{10,15}$')])),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'verbose_name': 'Student',
                'verbose_name_plural': 'Students',
                'db_table': 'students',
                'ordering': ['-id'],
            },
        ),
    ]
