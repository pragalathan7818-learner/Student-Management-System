from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StudentViewSet

# Use DefaultRouter to automatically map standard REST endpoints
router = DefaultRouter()
router.register(r'students', StudentViewSet, basename='student')

urlpatterns = [
    path('', include(router.urls)),
]
