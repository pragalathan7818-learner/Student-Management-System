from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator

# Phone number validator: accepts 10 to 15 digits with optional leading '+'
phone_regex = RegexValidator(
    regex=r'^\+?[0-9]{10,15}$',
    message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed."
)

class Student(models.Model):
    """
    Student model representing an enrolled academic record.
    Adheres strictly to the Academic SOP specifications.
    """
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(
        max_length=100,
        blank=False,
        null=False,
        help_text="Full legal name of the student"
    )
    email = models.EmailField(
        unique=True,
        blank=False,
        null=False,
        help_text="Unique institutional or personal email address"
    )
    department = models.CharField(
        max_length=100,
        blank=False,
        null=False,
        help_text="Academic department name (e.g. Computer Science)"
    )
    year = models.PositiveSmallIntegerField(
        validators=[
            MinValueValidator(1, message="Academic year must be at least 1."),
            MaxValueValidator(4, message="Academic year cannot exceed 4.")
        ],
        blank=False,
        null=False,
        help_text="Current academic year of study (1 to 4)"
    )
    phone = models.CharField(
        validators=[phone_regex],
        max_length=15,
        blank=False,
        null=False,
        help_text="Contact telephone/mobile number"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'students'
        ordering = ['-id']
        verbose_name = 'Student'
        verbose_name_plural = 'Students'

    def __str__(self):
        return f"[{self.id}] {self.name} - {self.department} (Year {self.year})"
