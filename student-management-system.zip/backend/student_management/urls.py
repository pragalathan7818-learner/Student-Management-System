"""
student_management URL Configuration
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    # Mount student API endpoints under /api/
    path('api/', include('students.urls')),
]
