# Django project package initialization
