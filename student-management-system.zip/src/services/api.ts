import { Student, StudentFormData, ApiFilterParams } from "../types";

/**
 * REST API Client for Student Management System
 * Integrates React frontend with Django REST Framework backend.
 * Uses VITE_API_BASE_URL environment variable with fallback to same-origin relative URLs.
 */
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "").replace(/\/$/, "");

export class ApiError extends Error {
  public status: number;
  public fieldErrors: Record<string, string[]>;

  constructor(message: string, status: number, fieldErrors: Record<string, string[]> = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (response.status === 204) {
    return {} as T;
  }

  let data: any;
  try {
    data = await response.json();
  } catch (err) {
    data = null;
  }

  if (!response.ok) {
    let errorMessage = "An error occurred while processing your request.";
    const fieldErrors: Record<string, string[]> = {};

    if (data && typeof data === "object") {
      if (typeof data.detail === "string") {
        errorMessage = data.detail;
      } else if (typeof data.message === "string") {
        errorMessage = data.message;
      } else {
        // Collect field-specific errors from Django REST Framework serializer
        for (const [key, value] of Object.entries(data)) {
          if (Array.isArray(value)) {
            fieldErrors[key] = value.map(String);
          } else if (typeof value === "string") {
            fieldErrors[key] = [value];
          }
        }
        if (Object.keys(fieldErrors).length > 0) {
          const firstKey = Object.keys(fieldErrors)[0];
          errorMessage = `${firstKey}: ${fieldErrors[firstKey][0]}`;
        }
      }
    } else {
      errorMessage = `Server returned status ${response.status}: ${response.statusText}`;
    }

    throw new ApiError(errorMessage, response.status, fieldErrors);
  }

  return data as T;
}

export const studentApi = {
  /**
   * READ: Fetch all students with optional search query, department filter, and year filter.
   * Corresponds to GET /api/students/
   */
  async getAll(params?: ApiFilterParams): Promise<Student[]> {
    const query = new URLSearchParams();
    if (params?.search) query.append("search", params.search.trim());
    if (params?.department && params.department !== "all") query.append("department", params.department);
    if (params?.year) query.append("year", String(params.year));

    const qs = query.toString();
    const url = `${API_BASE_URL}/api/students/${qs ? `?${qs}` : ""}`;

    try {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });
      return await handleResponse<Student[]>(response);
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError(
        "Backend server is unreachable. Please verify that the API server is running.",
        0
      );
    }
  },

  /**
   * READ ONE: Fetch single student record by ID.
   * Corresponds to GET /api/students/{id}/
   */
  async getById(id: number): Promise<Student> {
    const url = `${API_BASE_URL}/api/students/${id}/`;
    try {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });
      return await handleResponse<Student>(response);
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError("Failed to fetch student record details.", 0);
    }
  },

  /**
   * CREATE: Register a new student.
   * Corresponds to POST /api/students/
   */
  async create(data: StudentFormData): Promise<Student> {
    const url = `${API_BASE_URL}/api/students/`;
    const payload = {
      name: data.name.trim(),
      email: data.email.trim().toLowerCase(),
      department: data.department.trim(),
      year: Number(data.year),
      phone: data.phone.trim(),
    };

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(payload),
      });
      return await handleResponse<Student>(response);
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError("Failed to create student record.", 0);
    }
  },

  /**
   * UPDATE: Full record update.
   * Corresponds to PUT /api/students/{id}/
   */
  async update(id: number, data: StudentFormData): Promise<Student> {
    const url = `${API_BASE_URL}/api/students/${id}/`;
    const payload = {
      name: data.name.trim(),
      email: data.email.trim().toLowerCase(),
      department: data.department.trim(),
      year: Number(data.year),
      phone: data.phone.trim(),
    };

    try {
      const response = await fetch(url, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(payload),
      });
      return await handleResponse<Student>(response);
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError("Failed to update student record.", 0);
    }
  },

  /**
   * PARTIAL UPDATE: Update specified fields.
   * Corresponds to PATCH /api/students/{id}/
   */
  async patch(id: number, data: Partial<StudentFormData>): Promise<Student> {
    const url = `${API_BASE_URL}/api/students/${id}/`;
    try {
      const response = await fetch(url, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(data),
      });
      return await handleResponse<Student>(response);
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError("Failed to patch student record.", 0);
    }
  },

  /**
   * DELETE: Remove student record from database.
   * Corresponds to DELETE /api/students/{id}/
   */
  async delete(id: number): Promise<void> {
    const url = `${API_BASE_URL}/api/students/${id}/`;
    try {
      const response = await fetch(url, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
        },
      });
      await handleResponse<void>(response);
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError("Failed to delete student record.", 0);
    }
  },

  /**
   * RESET: Restore default demonstration student roster.
   * Corresponds to POST /api/students/reset/
   */
  async resetDemo(): Promise<void> {
    const url = `${API_BASE_URL}/api/students/reset/`;
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          Accept: "application/json",
        },
      });
      await handleResponse<void>(response);
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError("Failed to reset student database.", 0);
    }
  },

  /**
   * HEALTH CHECK: Test backend API reachability.
   * Corresponds to GET /api/health/
   */
  async checkHealth(): Promise<{ status: string; service: string }> {
    const url = `${API_BASE_URL}/api/health/`;
    const response = await fetch(url);
    return await handleResponse(response);
  },
};
