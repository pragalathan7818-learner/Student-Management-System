import React from "react";
import { Users, Building2, Calendar, CheckCircle2 } from "lucide-react";
import { Student } from "../types";

interface DashboardStatsProps {
  students: Student[];
  apiConnected: boolean;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({ students, apiConnected }) => {
  const totalStudents = students.length;
  const uniqueDepartments = new Set(students.map((s) => s.department)).size;

  const yearCounts = students.reduce(
    (acc, student) => {
      acc[student.year] = (acc[student.year] || 0) + 1;
      return acc;
    },
    {} as Record<number, number>
  );

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Metric 1: Total Registered Students */}
      <div
        id="stat-card-total-students"
        className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs flex items-center justify-between"
      >
        <div>
          <p className="text-xs font-medium text-stone-500 uppercase tracking-wider">
            Total Students
          </p>
          <p className="text-2xl font-bold text-stone-900 mt-1">{totalStudents}</p>
          <span className="text-xs text-stone-500 mt-1 inline-block">
            Enrolled across all programs
          </span>
        </div>
        <div className="w-12 h-12 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
          <Users className="w-6 h-6" />
        </div>
      </div>

      {/* Metric 2: Academic Departments */}
      <div
        id="stat-card-departments"
        className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs flex items-center justify-between"
      >
        <div>
          <p className="text-xs font-medium text-stone-500 uppercase tracking-wider">
            Departments
          </p>
          <p className="text-2xl font-bold text-stone-900 mt-1">{uniqueDepartments}</p>
          <span className="text-xs text-stone-500 mt-1 inline-block">
            Engineering & Sciences
          </span>
        </div>
        <div className="w-12 h-12 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
          <Building2 className="w-6 h-6" />
        </div>
      </div>

      {/* Metric 3: Year Distribution */}
      <div
        id="stat-card-year-distribution"
        className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs flex flex-col justify-between"
      >
        <div className="flex items-center justify-between">
          <p className="text-xs font-medium text-stone-500 uppercase tracking-wider">
            Year Breakdown
          </p>
          <Calendar className="w-4 h-4 text-stone-400" />
        </div>
        <div className="grid grid-cols-4 gap-1 mt-2 text-center">
          {[1, 2, 3, 4].map((yr) => (
            <div key={yr} className="bg-stone-50 rounded p-1">
              <span className="block text-[10px] text-stone-500 font-medium">Y{yr}</span>
              <span className="block text-xs font-bold text-stone-800">
                {yearCounts[yr] || 0}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Metric 4: API & Database Pipeline Status */}
      <div
        id="stat-card-api-status"
        className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs flex items-center justify-between"
      >
        <div>
          <p className="text-xs font-medium text-stone-500 uppercase tracking-wider">
            REST API & DB
          </p>
          <div className="flex items-center space-x-1.5 mt-1">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                apiConnected ? "bg-emerald-500 animate-pulse" : "bg-rose-500"
              }`}
            />
            <span className="text-sm font-bold text-stone-900">
              {apiConnected ? "Connected" : "Offline"}
            </span>
          </div>
          <span className="text-xs text-stone-500 mt-1 inline-block">
            DRF Endpoints active
          </span>
        </div>
        <div
          className={`w-12 h-12 rounded-lg flex items-center justify-center ${
            apiConnected ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
          }`}
        >
          <CheckCircle2 className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
};
