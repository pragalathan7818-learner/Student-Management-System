import React from "react";
import { AlertTriangle, Trash2, X } from "lucide-react";
import { Student } from "../types";

interface DeleteConfirmModalProps {
  isOpen: boolean;
  student: Student | null;
  onClose: () => void;
  onConfirm: () => Promise<void>;
  isDeleting: boolean;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  student,
  onClose,
  onConfirm,
  isDeleting,
}) => {
  if (!isOpen || !student) return null;

  return (
    <div
      id="delete-confirm-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/50 backdrop-blur-xs p-4"
    >
      <div
        id="delete-confirm-modal"
        className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 overflow-hidden transform transition-all animate-in fade-in zoom-in-95 duration-150"
      >
        <div className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">Confirm Record Deletion</h3>
              <p className="text-xs text-stone-500">
                This action executes a permanent HTTP DELETE request.
              </p>
            </div>
          </div>

          <div className="bg-stone-50 rounded-xl p-4 border border-stone-200 mb-4">
            <p className="text-xs text-stone-600 mb-1">
              Are you sure you want to delete the following student record?
            </p>
            <div className="space-y-0.5 mt-2">
              <p className="text-sm font-bold text-stone-900">{student.name}</p>
              <p className="text-xs text-stone-600 font-mono">
                ID: {student.id} • {student.email}
              </p>
              <p className="text-xs text-stone-500">
                {student.department} (Year {student.year})
              </p>
            </div>
          </div>

          <p className="text-xs text-rose-600 font-medium mb-6">
            Warning: This record will be deleted from the database. This action cannot be undone.
          </p>

          <div className="flex items-center justify-end space-x-3">
            <button
              id="cancel-delete-btn"
              type="button"
              onClick={onClose}
              disabled={isDeleting}
              className="px-4 py-2 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              id="confirm-delete-btn"
              type="button"
              onClick={onConfirm}
              disabled={isDeleting}
              className="inline-flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs transition-colors disabled:opacity-60"
            >
              {isDeleting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Deleting...</span>
                </>
              ) : (
                <>
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Record</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
