import React from "react";
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from "lucide-react";
import { ToastMessage } from "../types";

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastNotification: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div
      id="toast-notification-container"
      className="fixed bottom-4 right-4 z-50 flex flex-col space-y-2 max-w-sm w-full pointer-events-none"
    >
      {toasts.map((toast) => {
        let bgColor = "bg-white border-stone-200 text-stone-800";
        let icon = <Info className="w-5 h-5 text-indigo-500" />;

        if (toast.type === "success") {
          bgColor = "bg-white border-emerald-200 text-stone-800";
          icon = <CheckCircle2 className="w-5 h-5 text-emerald-600" />;
        } else if (toast.type === "error") {
          bgColor = "bg-white border-rose-200 text-stone-800";
          icon = <AlertCircle className="w-5 h-5 text-rose-600" />;
        } else if (toast.type === "warning") {
          bgColor = "bg-white border-amber-200 text-stone-800";
          icon = <AlertTriangle className="w-5 h-5 text-amber-600" />;
        }

        return (
          <div
            key={toast.id}
            id={`toast-${toast.id}`}
            className={`pointer-events-auto p-4 rounded-xl border shadow-lg flex items-start space-x-3 transform transition-all animate-in slide-in-from-bottom-5 duration-200 ${bgColor}`}
          >
            <div className="shrink-0 mt-0.5">{icon}</div>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold text-stone-900 leading-tight">{toast.title}</h4>
              <p className="text-xs text-stone-600 mt-0.5 leading-relaxed">{toast.message}</p>
            </div>
            <button
              onClick={() => onDismiss(toast.id)}
              className="text-stone-400 hover:text-stone-600 p-1 rounded-md transition-colors"
              title="Dismiss notification"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
