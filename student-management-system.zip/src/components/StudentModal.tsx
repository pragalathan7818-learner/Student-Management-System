import React, { useState, useEffect } from "react";
import { X, UserPlus, Check, AlertCircle } from "lucide-react";
import { Student, StudentFormData, FormErrors, DEPARTMENTS, ACADEMIC_YEARS } from "../types";

interface StudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (formData: StudentFormData) => Promise<boolean>;
  studentToEdit: Student | null;
  isSubmitting: boolean;
  apiFieldErrors?: Record<string, string[]>;
}

export const StudentModal: React.FC<StudentModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  studentToEdit,
  isSubmitting,
  apiFieldErrors,
}) => {
  const [formData, setFormData] = useState<StudentFormData>({
    name: "",
    email: "",
    department: DEPARTMENTS[0],
    year: 1,
    phone: "",
  });

  const [clientErrors, setClientErrors] = useState<FormErrors>({});

  // Synchronize state when opening for edit or new
  useEffect(() => {
    if (studentToEdit) {
      setFormData({
        name: studentToEdit.name,
        email: studentToEdit.email,
        department: studentToEdit.department,
        year: studentToEdit.year,
        phone: studentToEdit.phone,
      });
    } else {
      setFormData({
        name: "",
        email: "",
        department: DEPARTMENTS[0],
        year: 1,
        phone: "",
      });
    }
    setClientErrors({});
  }, [studentToEdit, isOpen]);

  if (!isOpen) return null;

  const validateForm = (): boolean => {
    const errors: FormErrors = {};

    // Name validation
    if (!formData.name.trim()) {
      errors.name = "Full name is required.";
    } else if (formData.name.trim().length < 2) {
      errors.name = "Name must be at least 2 characters.";
    } else if (formData.name.trim().length > 100) {
      errors.name = "Name cannot exceed 100 characters.";
    }

    // Email validation
    if (!formData.email.trim()) {
      errors.email = "Email address is required.";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email.trim())) {
        errors.email = "Please enter a valid academic or personal email.";
      }
    }

    // Department validation
    if (!formData.department) {
      errors.department = "Please select a department.";
    }

    // Year validation
    if (formData.year === "" || ![1, 2, 3, 4].includes(Number(formData.year))) {
      errors.year = "Please choose a valid academic year (1 to 4).";
    }

    // Phone validation
    if (!formData.phone.trim()) {
      errors.phone = "Contact phone number is required.";
    } else {
      const cleaned = formData.phone.trim().replace(/[\s-]/g, "");
      const phoneRegex = /^\+?[0-9]{10,15}$/;
      if (!phoneRegex.test(cleaned)) {
        errors.phone = "Enter a valid phone number (10–15 digits, optional +).";
      }
    }

    setClientErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    const success = await onSubmit(formData);
    if (success) {
      onClose();
    }
  };

  // Helper to get active error message (client or server API)
  const getErrorMessage = (field: keyof StudentFormData) => {
    if (clientErrors[field]) return clientErrors[field];
    if (apiFieldErrors && apiFieldErrors[field] && apiFieldErrors[field].length > 0) {
      return apiFieldErrors[field][0];
    }
    return null;
  };

  const isEditMode = Boolean(studentToEdit);

  return (
    <div
      id="student-form-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/50 backdrop-blur-xs p-4 overflow-y-auto"
    >
      <div
        id="student-form-modal"
        className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden my-8 transform transition-all animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">
                {isEditMode ? `Edit Student (ID: ${studentToEdit?.id})` : "Register New Student"}
              </h3>
              <p className="text-xs text-stone-500">
                {isEditMode
                  ? "Update academic and contact information"
                  : "Fill in all required fields to register student in database"}
              </p>
            </div>
          </div>
          <button
            id="close-student-modal-btn"
            onClick={onClose}
            className="text-stone-400 hover:text-stone-600 p-1.5 rounded-lg hover:bg-stone-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* General API error banner if any */}
          {apiFieldErrors?.general && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{apiFieldErrors.general[0]}</span>
            </div>
          )}

          {/* Name Field */}
          <div>
            <label
              htmlFor="student-name-input"
              className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1"
            >
              Full Legal Name <span className="text-rose-500">*</span>
            </label>
            <input
              id="student-name-input"
              type="text"
              value={formData.name}
              onChange={(e) => {
                setFormData({ ...formData, name: e.target.value });
                if (clientErrors.name) setClientErrors({ ...clientErrors, name: undefined });
              }}
              placeholder="e.g., Aarav Sharma"
              className={`w-full px-3.5 py-2 text-sm bg-white border rounded-lg focus:outline-hidden focus:ring-2 transition-all ${
                getErrorMessage("name")
                  ? "border-rose-400 focus:ring-rose-400 bg-rose-50/20"
                  : "border-stone-300 focus:ring-indigo-500"
              }`}
            />
            {getErrorMessage("name") && (
              <p className="mt-1 text-xs text-rose-600 flex items-center space-x-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                <span>{getErrorMessage("name")}</span>
              </p>
            )}
          </div>

          {/* Email Field */}
          <div>
            <label
              htmlFor="student-email-input"
              className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1"
            >
              Email Address <span className="text-rose-500">*</span>
            </label>
            <input
              id="student-email-input"
              type="email"
              value={formData.email}
              onChange={(e) => {
                setFormData({ ...formData, email: e.target.value });
                if (clientErrors.email) setClientErrors({ ...clientErrors, email: undefined });
              }}
              placeholder="e.g., aarav.sharma@college.edu"
              className={`w-full px-3.5 py-2 text-sm bg-white border rounded-lg focus:outline-hidden focus:ring-2 transition-all ${
                getErrorMessage("email")
                  ? "border-rose-400 focus:ring-rose-400 bg-rose-50/20"
                  : "border-stone-300 focus:ring-indigo-500"
              }`}
            />
            {getErrorMessage("email") && (
              <p className="mt-1 text-xs text-rose-600 flex items-center space-x-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                <span>{getErrorMessage("email")}</span>
              </p>
            )}
            <p className="mt-1 text-[11px] text-stone-400">
              Must be unique across all student database records.
            </p>
          </div>

          {/* Department & Year Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Department */}
            <div>
              <label
                htmlFor="student-department-select"
                className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1"
              >
                Department <span className="text-rose-500">*</span>
              </label>
              <select
                id="student-department-select"
                value={formData.department}
                onChange={(e) => {
                  setFormData({ ...formData, department: e.target.value });
                  if (clientErrors.department)
                    setClientErrors({ ...clientErrors, department: undefined });
                }}
                className={`w-full px-3 py-2 text-sm bg-white border rounded-lg focus:outline-hidden focus:ring-2 transition-all ${
                  getErrorMessage("department")
                    ? "border-rose-400 focus:ring-rose-400"
                    : "border-stone-300 focus:ring-indigo-500"
                }`}
              >
                {DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
              {getErrorMessage("department") && (
                <p className="mt-1 text-xs text-rose-600">{getErrorMessage("department")}</p>
              )}
            </div>

            {/* Academic Year */}
            <div>
              <label
                htmlFor="student-year-select"
                className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1"
              >
                Academic Year <span className="text-rose-500">*</span>
              </label>
              <select
                id="student-year-select"
                value={formData.year}
                onChange={(e) => {
                  setFormData({ ...formData, year: Number(e.target.value) });
                  if (clientErrors.year) setClientErrors({ ...clientErrors, year: undefined });
                }}
                className={`w-full px-3 py-2 text-sm bg-white border rounded-lg focus:outline-hidden focus:ring-2 transition-all ${
                  getErrorMessage("year")
                    ? "border-rose-400 focus:ring-rose-400"
                    : "border-stone-300 focus:ring-indigo-500"
                }`}
              >
                {ACADEMIC_YEARS.map((yr) => (
                  <option key={yr.value} value={yr.value}>
                    {yr.label}
                  </option>
                ))}
              </select>
              {getErrorMessage("year") && (
                <p className="mt-1 text-xs text-rose-600">{getErrorMessage("year")}</p>
              )}
            </div>
          </div>

          {/* Phone Field */}
          <div>
            <label
              htmlFor="student-phone-input"
              className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1"
            >
              Contact Phone <span className="text-rose-500">*</span>
            </label>
            <input
              id="student-phone-input"
              type="tel"
              value={formData.phone}
              onChange={(e) => {
                setFormData({ ...formData, phone: e.target.value });
                if (clientErrors.phone) setClientErrors({ ...clientErrors, phone: undefined });
              }}
              placeholder="e.g., +919876543210"
              className={`w-full px-3.5 py-2 text-sm bg-white border rounded-lg focus:outline-hidden focus:ring-2 transition-all ${
                getErrorMessage("phone")
                  ? "border-rose-400 focus:ring-rose-400 bg-rose-50/20"
                  : "border-stone-300 focus:ring-indigo-500"
              }`}
            />
            {getErrorMessage("phone") && (
              <p className="mt-1 text-xs text-rose-600 flex items-center space-x-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                <span>{getErrorMessage("phone")}</span>
              </p>
            )}
            <p className="mt-1 text-[11px] text-stone-400">
              10 to 15 digits, international prefix supported (e.g., +1, +91).
            </p>
          </div>

          {/* Actions Footer */}
          <div className="pt-4 border-t border-stone-200 flex items-center justify-end space-x-3">
            <button
              id="cancel-student-form-btn"
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              id="submit-student-form-btn"
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center space-x-1.5 px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors disabled:opacity-60"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Saving Record...</span>
                </>
              ) : (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>{isEditMode ? "Update Student" : "Save Student"}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
