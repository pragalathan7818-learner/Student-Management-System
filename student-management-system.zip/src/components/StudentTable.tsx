import React, { useState } from "react";
import {
  Edit,
  Trash2,
  Eye,
  ArrowUpDown,
  Mail,
  Phone,
  GraduationCap,
  Inbox,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import { Student } from "../types";

interface StudentTableProps {
  students: Student[];
  isLoading: boolean;
  error: string | null;
  onRetry: () => void;
  onView: (student: Student) => void;
  onEdit: (student: Student) => void;
  onDelete: (student: Student) => void;
  onAddStudent: () => void;
}

type SortField = "id" | "name" | "year" | "department";

export const StudentTable: React.FC<StudentTableProps> = ({
  students,
  isLoading,
  error,
  onRetry,
  onView,
  onEdit,
  onDelete,
  onAddStudent,
}) => {
  const [sortField, setSortField] = useState<SortField>("id");
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const sortedStudents = [...students].sort((a, b) => {
    let result = 0;
    if (sortField === "id") {
      result = a.id - b.id;
    } else if (sortField === "name") {
      result = a.name.localeCompare(b.name);
    } else if (sortField === "year") {
      result = a.year - b.year;
    } else if (sortField === "department") {
      result = a.department.localeCompare(b.department);
    }
    return sortAsc ? result : -result;
  });

  // Department color map
  const getDeptBadgeClass = (dept: string) => {
    if (dept.includes("Computer")) return "bg-blue-50 text-blue-700 border-blue-200";
    if (dept.includes("Information")) return "bg-cyan-50 text-cyan-700 border-cyan-200";
    if (dept.includes("Electronics")) return "bg-violet-50 text-violet-700 border-violet-200";
    if (dept.includes("Mechanical")) return "bg-amber-50 text-amber-700 border-amber-200";
    if (dept.includes("Civil")) return "bg-emerald-50 text-emerald-700 border-emerald-200";
    return "bg-stone-50 text-stone-700 border-stone-200";
  };

  const getYearBadge = (year: number) => {
    const yearColors: Record<number, string> = {
      1: "bg-teal-50 text-teal-700 border-teal-200",
      2: "bg-indigo-50 text-indigo-700 border-indigo-200",
      3: "bg-purple-50 text-purple-700 border-purple-200",
      4: "bg-rose-50 text-rose-700 border-rose-200",
    };
    return (
      <span
        className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold border ${
          yearColors[year] || "bg-stone-100 text-stone-700"
        }`}
      >
        Year {year}
      </span>
    );
  };

  // Error State
  if (error) {
    return (
      <div
        id="student-table-error-state"
        className="bg-white rounded-xl border border-rose-200 p-8 text-center my-6"
      >
        <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-3">
          <AlertCircle className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-stone-900 mb-1">
          Unable to Load Students
        </h3>
        <p className="text-sm text-stone-600 max-w-md mx-auto mb-4">{error}</p>
        <button
          id="retry-fetch-students-btn"
          onClick={onRetry}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Retry Connection</span>
        </button>
      </div>
    );
  }

  // Loading State (Skeleton Rows)
  if (isLoading) {
    return (
      <div
        id="student-table-loading-state"
        className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs"
      >
        <div className="p-4 border-b border-stone-200 animate-pulse bg-stone-50">
          <div className="h-4 bg-stone-200 rounded w-1/4"></div>
        </div>
        <div className="divide-y divide-stone-200">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="p-4 flex items-center justify-between animate-pulse">
              <div className="flex items-center space-x-4 w-1/3">
                <div className="w-8 h-8 bg-stone-200 rounded-full"></div>
                <div className="space-y-2 flex-1">
                  <div className="h-3 bg-stone-200 rounded w-3/4"></div>
                  <div className="h-2 bg-stone-100 rounded w-1/2"></div>
                </div>
              </div>
              <div className="h-3 bg-stone-200 rounded w-1/6"></div>
              <div className="h-3 bg-stone-200 rounded w-1/8"></div>
              <div className="h-7 bg-stone-200 rounded w-20"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Empty State
  if (students.length === 0) {
    return (
      <div
        id="student-table-empty-state"
        className="bg-white rounded-xl border border-stone-200 p-12 text-center my-6"
      >
        <div className="w-16 h-16 bg-stone-100 text-stone-400 rounded-full flex items-center justify-center mx-auto mb-4">
          <Inbox className="w-8 h-8" />
        </div>
        <h3 className="text-base font-semibold text-stone-900 mb-1">
          No Student Records Found
        </h3>
        <p className="text-sm text-stone-500 max-w-sm mx-auto mb-5">
          No students match your query, or no records currently exist in the database.
        </p>
        <button
          id="empty-add-student-btn"
          onClick={onAddStudent}
          className="inline-flex items-center space-x-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
        >
          <GraduationCap className="w-4 h-4" />
          <span>Register New Student</span>
        </button>
      </div>
    );
  }

  return (
    <div
      id="student-roster-container"
      className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs"
    >
      <div className="overflow-x-auto">
        <table id="student-roster-table" className="w-full text-left text-sm text-stone-700">
          <thead className="bg-stone-50 text-xs font-semibold text-stone-600 uppercase tracking-wider border-b border-stone-200">
            <tr>
              {/* ID Column */}
              <th
                scope="col"
                className="py-3.5 px-4 cursor-pointer hover:bg-stone-100 transition-colors"
                onClick={() => handleSort("id")}
                title="Click to sort by ID"
              >
                <div className="flex items-center space-x-1">
                  <span>ID</span>
                  <ArrowUpDown className="w-3 h-3 text-stone-400" />
                </div>
              </th>

              {/* Name Column */}
              <th
                scope="col"
                className="py-3.5 px-4 cursor-pointer hover:bg-stone-100 transition-colors"
                onClick={() => handleSort("name")}
                title="Click to sort by Name"
              >
                <div className="flex items-center space-x-1">
                  <span>Name</span>
                  <ArrowUpDown className="w-3 h-3 text-stone-400" />
                </div>
              </th>

              {/* Email Column */}
              <th scope="col" className="py-3.5 px-4">
                Email Address
              </th>

              {/* Department Column */}
              <th
                scope="col"
                className="py-3.5 px-4 cursor-pointer hover:bg-stone-100 transition-colors"
                onClick={() => handleSort("department")}
                title="Click to sort by Department"
              >
                <div className="flex items-center space-x-1">
                  <span>Department</span>
                  <ArrowUpDown className="w-3 h-3 text-stone-400" />
                </div>
              </th>

              {/* Year Column */}
              <th
                scope="col"
                className="py-3.5 px-4 cursor-pointer hover:bg-stone-100 transition-colors"
                onClick={() => handleSort("year")}
                title="Click to sort by Year"
              >
                <div className="flex items-center space-x-1">
                  <span>Year</span>
                  <ArrowUpDown className="w-3 h-3 text-stone-400" />
                </div>
              </th>

              {/* Phone Column */}
              <th scope="col" className="py-3.5 px-4">
                Phone
              </th>

              {/* Actions Column */}
              <th scope="col" className="py-3.5 px-4 text-right">
                Actions
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-stone-200">
            {sortedStudents.map((student) => (
              <tr
                key={student.id}
                id={`student-row-${student.id}`}
                className="hover:bg-stone-50/80 transition-colors"
              >
                {/* ID */}
                <td className="py-3.5 px-4 font-mono text-xs font-semibold text-stone-900 whitespace-nowrap">
                  {student.id}
                </td>

                {/* Name & Avatar */}
                <td className="py-3.5 px-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                      {student.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-semibold text-stone-900">{student.name}</span>
                  </div>
                </td>

                {/* Email */}
                <td className="py-3.5 px-4 whitespace-nowrap text-stone-600 text-xs">
                  <div className="flex items-center space-x-1.5">
                    <Mail className="w-3.5 h-3.5 text-stone-400" />
                    <span>{student.email}</span>
                  </div>
                </td>

                {/* Department */}
                <td className="py-3.5 px-4 whitespace-nowrap">
                  <span
                    className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${getDeptBadgeClass(
                      student.department
                    )}`}
                  >
                    {student.department}
                  </span>
                </td>

                {/* Year */}
                <td className="py-3.5 px-4 whitespace-nowrap">
                  {getYearBadge(student.year)}
                </td>

                {/* Phone */}
                <td className="py-3.5 px-4 whitespace-nowrap font-mono text-xs text-stone-600">
                  <div className="flex items-center space-x-1.5">
                    <Phone className="w-3.5 h-3.5 text-stone-400" />
                    <span>{student.phone}</span>
                  </div>
                </td>

                {/* Actions: View, Edit, Delete */}
                <td className="py-3.5 px-4 text-right whitespace-nowrap">
                  <div className="inline-flex items-center space-x-1">
                    {/* View Details */}
                    <button
                      id={`view-student-${student.id}-btn`}
                      onClick={() => onView(student)}
                      className="p-1.5 text-stone-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
                      title="View Student Details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {/* Edit */}
                    <button
                      id={`edit-student-${student.id}-btn`}
                      onClick={() => onEdit(student)}
                      className="p-1.5 text-stone-500 hover:text-amber-600 hover:bg-amber-50 rounded-md transition-colors"
                      title="Edit Student Record"
                    >
                      <Edit className="w-4 h-4" />
                    </button>

                    {/* Delete */}
                    <button
                      id={`delete-student-${student.id}-btn`}
                      onClick={() => onDelete(student)}
                      className="p-1.5 text-stone-500 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                      title="Delete Student Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
