import React from "react";
import { X, Mail, Phone, Building2, Calendar, Hash, Clock, CheckCircle } from "lucide-react";
import { Student } from "../types";

interface StudentDetailModalProps {
  isOpen: boolean;
  student: Student | null;
  onClose: () => void;
  onEdit: (student: Student) => void;
}

export const StudentDetailModal: React.FC<StudentDetailModalProps> = ({
  isOpen,
  student,
  onClose,
  onEdit,
}) => {
  if (!isOpen || !student) return null;

  return (
    <div
      id="student-detail-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/50 backdrop-blur-xs p-4 overflow-y-auto"
    >
      <div
        id="student-detail-modal"
        className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 overflow-hidden my-8 transform transition-all animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header with Avatar and Basic Info */}
        <div className="bg-gradient-to-br from-indigo-700 to-indigo-900 text-white p-6 relative">
          <button
            id="close-detail-modal-btn"
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-full bg-white text-indigo-700 flex items-center justify-center font-bold text-2xl shadow-md border-2 border-white/40">
              {student.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <span className="text-xs uppercase tracking-widest text-indigo-200 font-semibold">
                Student Profile
              </span>
              <h2 className="text-xl font-bold leading-tight">{student.name}</h2>
              <span className="text-xs text-indigo-100 font-mono">ID: {student.id}</span>
            </div>
          </div>
        </div>

        {/* Details list */}
        <div className="p-6 space-y-4">
          <div className="flex items-center space-x-3 p-3 bg-stone-50 rounded-xl border border-stone-100">
            <Mail className="w-4 h-4 text-indigo-600 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] uppercase font-semibold text-stone-400">Email Address</p>
              <p className="text-sm font-medium text-stone-900 truncate">{student.email}</p>
            </div>
          </div>

          <div className="flex items-center space-x-3 p-3 bg-stone-50 rounded-xl border border-stone-100">
            <Building2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] uppercase font-semibold text-stone-400">Department</p>
              <p className="text-sm font-medium text-stone-900">{student.department}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center space-x-3 p-3 bg-stone-50 rounded-xl border border-stone-100">
              <Calendar className="w-4 h-4 text-amber-600 shrink-0" />
              <div>
                <p className="text-[10px] uppercase font-semibold text-stone-400">Academic Year</p>
                <p className="text-sm font-bold text-stone-900">Year {student.year}</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-stone-50 rounded-xl border border-stone-100">
              <Phone className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <p className="text-[10px] uppercase font-semibold text-stone-400">Phone</p>
                <p className="text-xs font-mono font-medium text-stone-900">{student.phone}</p>
              </div>
            </div>
          </div>

          {/* Database metadata */}
          <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs text-stone-400">
            <span className="flex items-center space-x-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Record Status: Active</span>
            </span>
            <span className="flex items-center space-x-1 text-emerald-600 font-medium">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Verified DRF Record</span>
            </span>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 hover:bg-stone-100 rounded-lg transition-colors"
          >
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onEdit(student);
            }}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
          >
            Edit Record
          </button>
        </div>
      </div>
    </div>
  );
};
