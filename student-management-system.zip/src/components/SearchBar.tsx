import React from "react";
import { Search, Filter, X, UserPlus } from "lucide-react";
import { DEPARTMENTS, ACADEMIC_YEARS } from "../types";

interface SearchBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  selectedDept: string;
  onDeptChange: (value: string) => void;
  selectedYear: number | "";
  onYearChange: (value: number | "") => void;
  onResetFilters: () => void;
  onOpenAddModal: () => void;
  totalFilteredCount: number;
  totalCount: number;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchTerm,
  onSearchChange,
  selectedDept,
  onDeptChange,
  selectedYear,
  onYearChange,
  onResetFilters,
  onOpenAddModal,
  totalFilteredCount,
  totalCount,
}) => {
  const hasActiveFilters =
    Boolean(searchTerm.trim()) ||
    (Boolean(selectedDept) && selectedDept !== "all") ||
    selectedYear !== "";

  return (
    <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
        {/* Search input */}
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            id="student-search-input"
            type="text"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search by name, ID, email, or phone..."
            className="w-full pl-9 pr-8 py-2 text-sm bg-stone-50 border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white text-stone-900 placeholder-stone-400 transition-all"
          />
          {searchTerm && (
            <button
              onClick={() => onSearchChange("")}
              className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-stone-400 hover:text-stone-600"
              title="Clear search input"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter dropdowns & Add button */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
          {/* Department Filter */}
          <div className="relative flex-1 sm:flex-initial min-w-[170px]">
            <select
              id="department-filter-select"
              value={selectedDept}
              onChange={(e) => onDeptChange(e.target.value)}
              className="w-full py-2 px-3 text-xs sm:text-sm bg-stone-50 border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500 text-stone-800"
            >
              <option value="all">All Departments</option>
              {DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>

          {/* Academic Year Filter */}
          <div className="relative flex-1 sm:flex-initial min-w-[130px]">
            <select
              id="year-filter-select"
              value={selectedYear}
              onChange={(e) =>
                onYearChange(e.target.value === "" ? "" : Number(e.target.value))
              }
              className="w-full py-2 px-3 text-xs sm:text-sm bg-stone-50 border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500 text-stone-800"
            >
              <option value="">All Years</option>
              {ACADEMIC_YEARS.map((yr) => (
                <option key={yr.value} value={yr.value}>
                  Year {yr.value}
                </option>
              ))}
            </select>
          </div>

          {/* Clear Filters Button */}
          {hasActiveFilters && (
            <button
              id="clear-filters-btn"
              onClick={onResetFilters}
              className="inline-flex items-center space-x-1 px-2.5 py-2 rounded-lg text-xs font-medium text-stone-600 bg-stone-100 hover:bg-stone-200 border border-stone-300 transition-colors"
              title="Reset all search filters"
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}

          {/* Primary Action: Add Student */}
          <button
            id="add-student-btn"
            onClick={onOpenAddModal}
            className="inline-flex items-center space-x-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-xs transition-colors focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1 whitespace-nowrap"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Student</span>
          </button>
        </div>
      </div>

      {/* Live Result Feedback Counter */}
      <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
        <div>
          Showing <span className="font-semibold text-stone-800">{totalFilteredCount}</span> of{" "}
          <span className="font-semibold text-stone-800">{totalCount}</span> total students
          {hasActiveFilters && (
            <span className="ml-2 text-indigo-600 font-medium">(Filtered)</span>
          )}
        </div>
        <div className="text-[11px] text-stone-400">
          Search matches ID, Name, Email, Dept, Phone
        </div>
      </div>
    </div>
  );
};
