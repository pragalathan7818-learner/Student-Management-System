import React, { useState } from "react";
import { X, Layers, Code, ArrowRight, Database, Server, Monitor, CheckCircle } from "lucide-react";

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<"flow" | "endpoints" | "django">("flow");

  if (!isOpen) return null;

  return (
    <div
      id="architecture-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/60 backdrop-blur-xs p-4 overflow-y-auto"
    >
      <div
        id="architecture-modal"
        className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-stone-200 overflow-hidden my-6 transform transition-all animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">
                System Architecture & SOP Specifications
              </h3>
              <p className="text-xs text-stone-500">
                Academic Full-Stack Student Management System Design
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-600 p-1.5 rounded-lg hover:bg-stone-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-stone-200 flex space-x-4 bg-white text-xs font-semibold text-stone-600">
          <button
            onClick={() => setActiveTab("flow")}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === "flow"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent hover:text-stone-900"
            }`}
          >
            Architecture & Data Flow
          </button>
          <button
            onClick={() => setActiveTab("endpoints")}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === "endpoints"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent hover:text-stone-900"
            }`}
          >
            REST API Endpoints
          </button>
          <button
            onClick={() => setActiveTab("django")}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === "django"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent hover:text-stone-900"
            }`}
          >
            Django Backend Schema
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 max-h-[70vh] overflow-y-auto text-stone-700 text-xs">
          {activeTab === "flow" && (
            <div className="space-y-6">
              {/* Visual Pipeline */}
              <div className="bg-stone-50 rounded-xl p-4 border border-stone-200">
                <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-4 text-center">
                  Tier-by-Tier Architectural Hierarchy
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-center text-center">
                  <div className="bg-white p-3 rounded-lg border border-stone-200 shadow-xs">
                    <Monitor className="w-5 h-5 text-indigo-600 mx-auto mb-1" />
                    <span className="font-bold block text-stone-900">User / Client</span>
                    <span className="text-[10px] text-stone-500">React + Vite (Vercel)</span>
                  </div>
                  <div className="flex justify-center text-stone-400">
                    <ArrowRight className="w-4 h-4 hidden sm:block" />
                    <span className="sm:hidden">↓</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-stone-200 shadow-xs">
                    <Server className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
                    <span className="font-bold block text-stone-900">Django Backend</span>
                    <span className="text-[10px] text-stone-500">DRF + Serializer</span>
                  </div>
                  <div className="flex justify-center text-stone-400">
                    <ArrowRight className="w-4 h-4 hidden sm:block" />
                    <span className="sm:hidden">↓</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-stone-200 shadow-xs">
                    <Database className="w-5 h-5 text-amber-600 mx-auto mb-1" />
                    <span className="font-bold block text-stone-900">Database Layer</span>
                    <span className="text-[10px] text-stone-500">Django ORM + SQLite</span>
                  </div>
                </div>
              </div>

              {/* Data Flow Description */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                  Request Execution Flow
                </h4>
                <ol className="space-y-2 border-l-2 border-indigo-200 pl-4">
                  <li className="relative">
                    <span className="font-semibold text-stone-900">1. User Interaction (React):</span>
                    <p className="text-stone-600 mt-0.5">
                      User submits a form (e.g., Create Student). React performs client-side field validation and initiates a `fetch()` request with a JSON payload.
                    </p>
                  </li>
                  <li className="relative">
                    <span className="font-semibold text-stone-900">2. REST API Gateway:</span>
                    <p className="text-stone-600 mt-0.5">
                      Request arrives at `/api/students/`. Django CORS headers permit the request and URL router maps to `StudentViewSet`.
                    </p>
                  </li>
                  <li className="relative">
                    <span className="font-semibold text-stone-900">3. DRF Serializer Validation:</span>
                    <p className="text-stone-600 mt-0.5">
                      `StudentSerializer` checks field types, required constraints, email uniqueness, and phone format. Rejects with HTTP 400 on error.
                    </p>
                  </li>
                  <li className="relative">
                    <span className="font-semibold text-stone-900">4. Django ORM Execution:</span>
                    <p className="text-stone-600 mt-0.5">
                      Serializer calls `serializer.save()`, which triggers Django ORM to generate SQL `INSERT` / `UPDATE` statements to the relational database.
                    </p>
                  </li>
                  <li className="relative">
                    <span className="font-semibold text-stone-900">5. Response & UI Mutation:</span>
                    <p className="text-stone-600 mt-0.5">
                      Server responds with HTTP 201 Created containing the persisted student record. React updates state and shows a success toast.
                    </p>
                  </li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === "endpoints" && (
            <div className="space-y-4">
              <p className="text-stone-600">
                The application implements the standard RESTful specification with explicit HTTP status codes:
              </p>
              <div className="border border-stone-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 border-b border-stone-200 font-semibold text-stone-700">
                    <tr>
                      <th className="py-2.5 px-3">Method</th>
                      <th className="py-2.5 px-3">Endpoint</th>
                      <th className="py-2.5 px-3">Success Code</th>
                      <th className="py-2.5 px-3">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200">
                    <tr>
                      <td className="py-2 px-3 font-mono font-bold text-emerald-600">GET</td>
                      <td className="py-2 px-3 font-mono">/api/students/</td>
                      <td className="py-2 px-3 font-mono">200 OK</td>
                      <td className="py-2 px-3">List all students with search & filtering</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono font-bold text-blue-600">GET</td>
                      <td className="py-2 px-3 font-mono">/api/students/{`{id}`}/</td>
                      <td className="py-2 px-3 font-mono">200 OK</td>
                      <td className="py-2 px-3">Retrieve individual student by ID</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono font-bold text-indigo-600">POST</td>
                      <td className="py-2 px-3 font-mono">/api/students/</td>
                      <td className="py-2 px-3 font-mono">201 Created</td>
                      <td className="py-2 px-3">Create new student record with validation</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono font-bold text-amber-600">PUT</td>
                      <td className="py-2 px-3 font-mono">/api/students/{`{id}`}/</td>
                      <td className="py-2 px-3 font-mono">200 OK</td>
                      <td className="py-2 px-3">Complete update of existing record</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono font-bold text-purple-600">PATCH</td>
                      <td className="py-2 px-3 font-mono">/api/students/{`{id}`}/</td>
                      <td className="py-2 px-3 font-mono">200 OK</td>
                      <td className="py-2 px-3">Partial update of specific fields</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-mono font-bold text-rose-600">DELETE</td>
                      <td className="py-2 px-3 font-mono">/api/students/{`{id}`}/</td>
                      <td className="py-2 px-3 font-mono">204 No Content</td>
                      <td className="py-2 px-3">Remove student record permanently</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "django" && (
            <div className="space-y-4">
              <div>
                <h4 className="font-bold text-stone-900 mb-1">Student Django Model (`models.py`)</h4>
                <div className="bg-stone-900 text-stone-100 p-3 rounded-lg font-mono text-[11px] overflow-x-auto">
{`from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator

class Student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    department = models.CharField(max_length=50)
    year = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)]
    )
    phone = models.CharField(
        max_length=15,
        validators=[RegexValidator(r'^\\+?[0-9]{10,15}$', 'Invalid phone number format')]
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return f"{self.name} ({self.email})"`}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-stone-900 mb-1">DRF Serializer (`serializers.py`)</h4>
                <div className="bg-stone-900 text-stone-100 p-3 rounded-lg font-mono text-[11px] overflow-x-auto">
{`from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['id', 'name', 'email', 'department', 'year', 'phone', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']`}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 hover:bg-stone-100 rounded-lg transition-colors"
          >
            Close Overview
          </button>
        </div>
      </div>
    </div>
  );
};
