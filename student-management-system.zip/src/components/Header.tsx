import React from "react";
import { GraduationCap, Database, Layers, RefreshCw } from "lucide-react";

interface HeaderProps {
  onOpenArchitecture: () => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  onResetDemo: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenArchitecture,
  onRefresh,
  isRefreshing,
  onResetDemo,
}) => {
  return (
    <header className="border-b border-stone-200 bg-white sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold text-stone-900 tracking-tight">
                  Student Management System
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Full-Stack Academic Project
                </span>
              </div>
              <p className="text-xs text-stone-500 hidden md:block">
                React Frontend • REST API • Django Backend • Django ORM • SQLite
              </p>
            </div>
          </div>

          {/* Quick Action Navigation */}
          <div className="flex items-center space-x-2">
            <button
              id="view-architecture-btn"
              onClick={onOpenArchitecture}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 transition-colors border border-stone-200"
              title="Inspect System Architecture & Flow"
            >
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">Architecture & Flow</span>
            </button>

            <button
              id="reset-demo-btn"
              onClick={onResetDemo}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 transition-colors border border-amber-200"
              title="Reset records to default sample roster"
            >
              <Database className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Reset Seed</span>
            </button>

            <button
              id="refresh-data-btn"
              onClick={onRefresh}
              disabled={isRefreshing}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 transition-colors disabled:opacity-50"
              title="Refresh student records from database"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-stone-600 ${isRefreshing ? "animate-spin" : ""}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
