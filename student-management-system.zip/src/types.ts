export interface Student {
  id: number;
  name: string;
  email: string;
  department: string;
  year: number;
  phone: string;
  created_at?: string;
  updated_at?: string;
}

export interface StudentFormData {
  name: string;
  email: string;
  department: string;
  year: number | "";
  phone: string;
}

export interface FormErrors {
  name?: string;
  email?: string;
  department?: string;
  year?: string;
  phone?: string;
  general?: string;
}

export type DepartmentType =
  | "Computer Science"
  | "Information Technology"
  | "Electronics & Communication"
  | "Mechanical Engineering"
  | "Civil Engineering"
  | "Electrical Engineering"
  | "Biotechnology";

export const DEPARTMENTS: DepartmentType[] = [
  "Computer Science",
  "Information Technology",
  "Electronics & Communication",
  "Mechanical Engineering",
  "Civil Engineering",
  "Electrical Engineering",
  "Biotechnology",
];

export const ACADEMIC_YEARS = [
  { value: 1, label: "1st Year (Freshman)" },
  { value: 2, label: "2nd Year (Sophomore)" },
  { value: 3, label: "3rd Year (Junior)" },
  { value: 4, label: "4th Year (Senior)" },
];

export interface ToastMessage {
  id: string;
  type: "success" | "error" | "info" | "warning";
  title: string;
  message: string;
}

export interface ApiFilterParams {
  search?: string;
  department?: string;
  year?: number | "";
}
