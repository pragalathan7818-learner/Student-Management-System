import React, { useState, useEffect, useCallback } from "react";
import { Header } from "./components/Header";
import { DashboardStats } from "./components/DashboardStats";
import { SearchBar } from "./components/SearchBar";
import { StudentTable } from "./components/StudentTable";
import { StudentModal } from "./components/StudentModal";
import { StudentDetailModal } from "./components/StudentDetailModal";
import { DeleteConfirmModal } from "./components/DeleteConfirmModal";
import { ToastNotification } from "./components/ToastNotification";
import { ArchitectureModal } from "./components/ArchitectureModal";
import { studentApi, ApiError } from "./services/api";
import { Student, StudentFormData, ToastMessage } from "./types";

export default function App() {
  // Main data & state
  const [students, setStudents] = useState<Student[]>([]);
  const [allStudentsCount, setAllStudentsCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [apiConnected, setApiConnected] = useState<boolean>(true);

  // Search and filter state
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedDept, setSelectedDept] = useState<string>("all");
  const [selectedYear, setSelectedYear] = useState<number | "">("");

  // Modal controls
  const [studentModalOpen, setStudentModalOpen] = useState<boolean>(false);
  const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState<boolean>(false);
  const [studentToView, setStudentToView] = useState<Student | null>(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState<boolean>(false);
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);
  const [architectureModalOpen, setArchitectureModalOpen] = useState<boolean>(false);

  // Form submission and deletion states
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [apiFieldErrors, setApiFieldErrors] = useState<Record<string, string[]> | undefined>(
    undefined
  );

  // Toast feedback state
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (
    type: "success" | "error" | "info" | "warning",
    title: string,
    message: string
  ) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Fetch student roster from REST API
  const loadStudents = useCallback(
    async (showSilentRefresh = false) => {
      if (showSilentRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      try {
        const data = await studentApi.getAll({
          search: searchTerm,
          department: selectedDept,
          year: selectedYear,
        });
        setStudents(data);
        setApiConnected(true);

        // Fetch total count without filters for reference
        if (!searchTerm && selectedDept === "all" && selectedYear === "") {
          setAllStudentsCount(data.length);
        }
      } catch (err: any) {
        console.error("Error loading students:", err);
        setApiConnected(false);
        const msg = err.message || "Failed to connect to Django REST API.";
        setError(msg);
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [searchTerm, selectedDept, selectedYear]
  );

  // Initial load
  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  // Also query total count once
  useEffect(() => {
    studentApi
      .getAll()
      .then((res) => {
        setAllStudentsCount(res.length);
        setApiConnected(true);
      })
      .catch(() => {
        setApiConnected(false);
      });
  }, []);

  // Handlers for Add / Edit Modal
  const handleOpenAddModal = () => {
    setStudentToEdit(null);
    setApiFieldErrors(undefined);
    setStudentModalOpen(true);
  };

  const handleOpenEditModal = (student: Student) => {
    setStudentToEdit(student);
    setApiFieldErrors(undefined);
    setStudentModalOpen(true);
  };

  const handleOpenDetailModal = (student: Student) => {
    setStudentToView(student);
    setDetailModalOpen(true);
  };

  const handleOpenDeleteModal = (student: Student) => {
    setStudentToDelete(student);
    setDeleteModalOpen(true);
  };

  const handleResetFilters = () => {
    setSearchTerm("");
    setSelectedDept("all");
    setSelectedYear("");
  };

  // Submit Add / Edit Form (POST / PUT)
  const handleSubmitStudentForm = async (formData: StudentFormData): Promise<boolean> => {
    setIsSubmitting(true);
    setApiFieldErrors(undefined);

    try {
      if (studentToEdit) {
        // UPDATE (PUT /api/students/{id}/)
        const updated = await studentApi.update(studentToEdit.id, formData);
        addToast(
          "success",
          "Student Record Updated",
          `Updated information for ${updated.name} (ID: ${updated.id}) successfully.`
        );
      } else {
        // CREATE (POST /api/students/)
        const created = await studentApi.create(formData);
        addToast(
          "success",
          "Student Registered",
          `Added ${created.name} (ID: ${created.id}) to the student database.`
        );
      }

      await loadStudents(true);
      setIsSubmitting(false);
      return true;
    } catch (err: any) {
      setIsSubmitting(false);
      if (err instanceof ApiError && Object.keys(err.fieldErrors).length > 0) {
        setApiFieldErrors(err.fieldErrors);
        addToast("error", "Validation Error", "Please resolve the errors highlighted below.");
      } else {
        const errorMsg = err.message || "Failed to persist student record.";
        setApiFieldErrors({ general: [errorMsg] });
        addToast("error", "Server Error", errorMsg);
      }
      return false;
    }
  };

  // Submit Delete (DELETE /api/students/{id}/)
  const handleConfirmDelete = async () => {
    if (!studentToDelete) return;
    setIsDeleting(true);

    try {
      await studentApi.delete(studentToDelete.id);
      addToast(
        "success",
        "Student Record Removed",
        `Student ID: ${studentToDelete.id} (${studentToDelete.name}) was successfully deleted.`
      );
      setDeleteModalOpen(false);
      setStudentToDelete(null);
      await loadStudents(true);
    } catch (err: any) {
      addToast("error", "Deletion Failed", err.message || "Could not delete student record.");
    } finally {
      setIsDeleting(false);
    }
  };

  // Reset database to initial mock seed
  const handleResetDemo = async () => {
    try {
      await studentApi.resetDemo();
      addToast(
        "info",
        "Database Reset",
        "Student database restored to default college demonstration records."
      );
      await loadStudents(true);
    } catch (err: any) {
      addToast("error", "Reset Error", err.message || "Unable to reset database.");
    }
  };

  return (
    <div className="min-h-screen bg-stone-100 text-stone-800 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <Header
        onOpenArchitecture={() => setArchitectureModalOpen(true)}
        onRefresh={() => loadStudents(true)}
        isRefreshing={isRefreshing}
        onResetDemo={handleResetDemo}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Dashboard Metric Cards */}
        <DashboardStats students={students} apiConnected={apiConnected} />

        {/* Search & Filter Bar */}
        <SearchBar
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          selectedDept={selectedDept}
          onDeptChange={setSelectedDept}
          selectedYear={selectedYear}
          onYearChange={setSelectedYear}
          onResetFilters={handleResetFilters}
          onOpenAddModal={handleOpenAddModal}
          totalFilteredCount={students.length}
          totalCount={allStudentsCount || students.length}
        />

        {/* Student Roster Table */}
        <StudentTable
          students={students}
          isLoading={isLoading}
          error={error}
          onRetry={() => loadStudents(false)}
          onView={handleOpenDetailModal}
          onEdit={handleOpenEditModal}
          onDelete={handleOpenDeleteModal}
          onAddStudent={handleOpenAddModal}
        />
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 bg-white py-4 text-center text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Student Management System • College Academic Project</span>
          <span className="font-mono text-[11px] text-stone-400">
            React 19 • Vite • DRF • Django ORM • SQLite
          </span>
        </div>
      </footer>

      {/* Add / Edit Student Modal */}
      <StudentModal
        isOpen={studentModalOpen}
        onClose={() => setStudentModalOpen(false)}
        onSubmit={handleSubmitStudentForm}
        studentToEdit={studentToEdit}
        isSubmitting={isSubmitting}
        apiFieldErrors={apiFieldErrors}
      />

      {/* Student Details View Modal */}
      <StudentDetailModal
        isOpen={detailModalOpen}
        student={studentToView}
        onClose={() => setDetailModalOpen(false)}
        onEdit={handleOpenEditModal}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteModalOpen}
        student={studentToDelete}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeleting}
      />

      {/* System Architecture & SOP Specifications Modal */}
      <ArchitectureModal
        isOpen={architectureModalOpen}
        onClose={() => setArchitectureModalOpen(false)}
      />

      {/* Toast Notification Container */}
      <ToastNotification toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
